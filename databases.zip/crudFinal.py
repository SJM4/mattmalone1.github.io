# by Matthew Malone matthew.malone1@snhu.edu
# July 24, 2020
# For CS-499 Computer Science Capstone
# This program implements the CRUD functions using pymongo.
# These functions are then enhanced by fifty, industry, and aggregate
# producing a small but solid pymango database interface.
#

# Data forthis is in json format. The mongo client must be running
# and have access to the referenced database. In this case that
# is stocks with the document market.
import json
from bson import json_util
from bson.son import SON
from pymongo import MongoClient

connection = MongoClient('localhost', 27017)
db = connection['market']
collection = db['stocks']


# Create an entry in the referenced database.
def create(document):
  try:
    result=collection.insert_one(document)
  except ValidationError as ve:
    abort(400,str(ve))
  return result

# Find a document from the database.
def read(document):
  try:
    result = collection.find_one(document)
  except ValidationError as ve:
    abort(400,str(ve))
  return result
  
# Update an entry in the referenced database.  
def update(document, upd):
  try:
    result= collection.update_one(document, upd)
  except ValidationError as ve:
    abort(400,str(ve))
  return result

# Delete a document from the referenced database.
def delete(document):
  try:
    result = collection.delete_one(document)
  except ValidationError as ve:
    abort(400,str(ve))
  return result
  

# Get the fifty day moving average between specified low and high  
def fifty(low, high):
  result = collection.find({"50-Day Simple Moving Average": {"$gte":low, "$lte": high}})
  result_count = result.count()
  return result_count

# find the specified industry items.
def industry(stuff):
  result = collection.find({"Industry": stuff},{"Ticker": 1})
  return result

# Find all the items matching the specified general category of stock.
def aggregate(morestuff):
  pipeline = [ { "$match": { "Sector": morestuff }},
              { "$group": {"_id" : "$Industry", "Shares Outstanding":{"$sum":"$Shares Outstanding"}}},
              { "$sort": SON([("Sector", 1), ("Industry", 1)])}]
  result = collection.aggregate(pipeline)
  return result


def main():

	#basic document setup to test create update and delete
    myDocument = {"Ticker":"Test Stock"}
    myDocument2 = {"Volume": 1851234}
    print create(myDocument)
    print read(myDocument)
    print update(myDocument, {"$set":myDocument2})
    print delete(myDocument)

    # Calling the enhancement functions.
    # Setting the 50 day simple moving average range.
    print fifty(0, 1)

    # Find everything in the Medical laboritories and research category.
    for x in industry("Medical Laboratories & Research"):
      print(x)

    # Find everything in healthcare.
    for x in aggregate("Healthcare"):
      print(x)
main()