/*
 * Verification.h
 *
 *  Created on: Jul 22, 2020
 *      Author: matth
 */

#ifndef VERIFICATION_H_
#define VERIFICATION_H_

#include <string>

class Verification {
	private:
		bool authenticate = false;
		void Auth();

    // This constructor gathers the information needed to create a verification
    // object. It call the private methods Auth() and MD5() to accomplish this.
	public:
		Verification();
		bool getAuth();
		std::string getUser();
};



#endif /* VERIFICATION_H_ */
