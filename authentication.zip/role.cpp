/*
 * Author: Matthew Malone   matthew.malone1@snhu.edu
 * Date: July 21, 2020
 * File: role.cpp
 * Description: This file opens first sets the path for the role description
 * file. Then it will open and print that file when the Display method is
 * called.
 */

#include <string>
#include <iostream>
#include <fstream>

using namespace std;

class Role {
	private:
		string path;
		string User;

	public:
		Role(string);
		void Display();
		string getPath();
};


Role::Role(string User){
    // setup the path object
    path = User + ".txt";
}


string Role::getPath(){
	return path;
}

void Role::Display() {
	string line;


	ifstream instring(getPath(), ifstream::in);


	// Check that the stream is valid
	if (!instring.good()) {
		cout << "Input stream to file " << path
			<< " is not valid" << endl;
		}

		// If we get here the file stream is valid

		// Print the accessed file
		while(getline(instring, line)) {
			cout << line << endl;
        }


        instring.close();
    }


