/*
 * role.h
 *
 *  Created on: Jul 22, 2020
 *      Author: matth
 */

#ifndef ROLE_H_
#define ROLE_H_

#include <string>

class Role {
private:
	std::string User;

public:
	Role(std::string User);
	void Display();
};



#endif /* ROLE_H_ */
