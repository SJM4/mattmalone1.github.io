/*
 * Author: Matthew Malone   matthew.malone1@snhu.edu
 * Date: July 21, 2020
 * File: Verification.cpp
 * Description: This file creates an object which will verify the authenticity
 * of a username and password combination against a credentials file using
 * a MD5 hash.
 */

#include <cstdio>
#include <cstdlib>
#include <iostream>
#include <fstream>
#include <vector>
#include <iterator>
#include <sstream>
#include "MD5.h"

using namespace std;

class Verification {
	private:
		string username = " ";
		string MD5password;
		string type = "";
		bool authenticate = false;
		void Auth();
		void split(const std::string &s, char delim, std::vector<std::string> &elems);

    // This constructor gathers the information needed to create a verification
    // object. It call the private methods Auth() and MD5() to accomplish this.
	public:
		Verification();
		bool getAuth();
		string getUser();
};

	Verification::Verification() {
		int count = 0;
        string password = "";

        // Allow the users to exit if quit is typed.
        while(username.compare("quit")) {

            // get username
            cout << "To quit type 'quit' in the username field." << endl;;
            cout << "Enter Username: ";
            cin >> username;

            // facilitate quitting if quit is typed.
            if (!username.compare("quit")) {
                continue;
            }

            // get password
            cout << "Enter Password: ";
            cin.ignore();
            getline(cin, password, '\n');

            // Use a try catch block to handle any MD5 exception.
            try {
            	MD5password = md5(password); //Call the provided MD5 function
            }
            catch (exception e){
                cerr <<"MD5 is throwing an exception." << endl;
                exit(1);
            }

            // Auth performs username and password comparisons
            try {
            	Auth();
            } catch (exception e){
                cerr << "Auth is throwing an exception." << endl;
                exit(2);
            }

            // If the authentication object now reads true return to main.
            if (authenticate) {
                break;
            }

            ++count;
            // break if the login attempts are equal to 3.
            if (count >= 3){
                cout << "Authentication Failed" << endl;
                break;
            }

        }
    }

	// taken from http://stackoverflow.com/a/236803/248823
	void Verification::split(const std::string &s, char delim, std::vector<std::string> &elems) {
	    std::stringstream ss;
	    ss.str(s);
	    std::string item;
	    while (std::getline(ss, item, delim)) {
	        elems.push_back(item);
	    }
	}


    // This method matches the username and password determining if the
    // authentication is true or not.
    void Verification::Auth() {
        string password = "";
        string user = "";
        string line;
        string passTemp, userTemp;

        //System.out.println(System.getProperty("user.dir"));
        // The directory structure automatically defaulted to the top level
        // of the Authentication folder. By opting to keep all the files
        // together I needed to extend the file path.
        ifstream inFS("credentials.txt", ifstream::in);

        // Check that the stream is valid
        if (!inFS.good()) {
            std::cout << "Input stream to file " << "credentials.txt"
                << " is not valid" << endl;
        }

        // If we get here the file stream is valid

        while(getline(inFS, line))
            // Get the items that matter in the password file.
        	{
        	    vector<string> row_values;

        	    split(line, '\t', row_values);

        	    userTemp = row_values[0];
        	    passTemp = row_values[1];

        	    if((!userTemp.compare(username)) && (!passTemp.compare(MD5password))){

        	    	user = row_values[0];
        	    	password = row_values[1];
        	    	type = row_values[3];

        	    }
        	}
            // Compare given password and username to the file password and
            // username.
            if ((!password.compare(MD5password)) && (!user.compare(username))) {
            	authenticate = true;
            }
       inFS.close();
    }

    bool Verification::getAuth(){
        return authenticate;
    }
    string Verification::getUser() {
    	return type;

    }

