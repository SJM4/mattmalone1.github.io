/*
 * Author: Matthew Malone   matthew.malone1@snhu.edu
 * Date: July 21, 2020
 * Program: Authentication.cpp
 * Description: This program has two classes one which verifies the username
 * and password and one which displays the role the user is trying to access.
 *
 */

#include <cstdio>
#include <cstdlib>
#include <iostream>
#include "verification.h"
#include "role.h"

using namespace std;

int main() {

    // Authenticate the username and password
    Verification Ver;

    // If authentication succeeds print the information in the role object.
    if (Ver.getAuth()) {

        Role role1(Ver.getUser()); // set the path

        try{
            role1.Display();  // Display the role file.
        }
        catch (exception e){
            cout << "IOException from the role display function." << endl;
            exit(3);
        }
    }



}

